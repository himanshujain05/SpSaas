
var app = angular.module( 'App', ['ngStorage'] );


app.controller('Sportido', ["$scope", "$window", "$location", "$http", "$localStorage",
 function ($scope, $window, $location, $http, $localStorage) {
 
    $scope.msg = "Hi";

    // var ctrl = this;
    
    var montharray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
    var montharrayfull = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
    


    $scope.init = function()
    {
        $scope.showform = false;
        if($localStorage.isLogin == true)
        {
                $scope.showform = true;
                $localStorage.isLogin = true;
                $scope.bookData = $localStorage.loginData;
                $scope.logbody = "bgw";
        }
    }

    
    $scope.login = function()
    {
        var flag = 0;
        if($scope.usermobile == undefined || $scope.usermobile == "")
        {
            flag = 1;
        }
        if($scope.userpass == undefined || $scope.userpass == "")
        {
             flag = 1;
        }


        if(flag == 0)
        {


             $scope.Submittxt = "Submitting";
             $scope.disbtn = true;
            var reqdata =  "mobile_no=" + $scope.usermobile + "&password=" + $scope.userpass;
         var request = $http({
            method: "POST",
            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'},
            dataType: "json",
            url: "http://ec2-34-193-7-167.compute-1.amazonaws.com/saas/login",
            data: reqdata
        });
          request.then(function (result) {
            if(result.data.success == 1)
            {
                $scope.showform = true;
                $localStorage.isLogin = true;
                $scope.bookData = result.data;
                $localStorage.loginData = result.data;
                $scope.logbody = "bgw";
                
            }
        })
        
        }
    }

    $scope.goCal = function(item)
    {
        var data = btoa("serviceid=" + item.service_id + "&servicename="  + item.service_name + "&subtype="  + item.subtype  + "&providerid="  + $scope.bookData.provider_id + "&providername="  + $scope.bookData.provider_name  + "&inventory_type="  + item.inventory_type );
         $window.location.href = "home.html?" + data;
    }
 }]);


app.directive('onlyLettersInput', onlyLettersInput);

function onlyLettersInput() {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^a-zA-Z\s]/g, '');
                //console.log(transformedInput)
                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
};


app.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                     text = text.toString();
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});