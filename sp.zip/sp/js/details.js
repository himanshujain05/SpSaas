
var app = angular.module( 'App', [] );


app.controller('Sportido', ["$scope", "$window", "$location", "$http",
 function ($scope, $window, $location, $http) {
 
    $scope.msg = "Hi";

    // var ctrl = this;
    
    var montharray = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
    var montharrayfull = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
    


    $scope.init = function()
    {
        $scope.showform = false;
        $scope.Submittxt = "Submit";
        $scope.msgdata1 = "Exact";
        $scope.BookDate = "9 May, 2017";
         var url = $location.absUrl();
        url = url.split("#")[0];
        var data = atob(url.split("?")[1]);
        var weekDay = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday","Saturday"];
        console.log(data);
        var qstring = data.split("&");
        for(var i=0;i<qstring.length;i++)
        {
            if (qstring[i].indexOf("date") != -1) {
                 $scope.selDate = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("provider_id") != -1) {
                 $scope.providerId = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("package_id") != -1) {
                 $scope.packageId = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("slot") != -1) {
                 $scope.selSlot = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("court") != -1) {
                 $scope.court = qstring[i].split('=')[1];
            }
             else if (qstring[i].indexOf("name") != -1) {
                 $scope.username = qstring[i].split('=')[1];
            }
             else if (qstring[i].indexOf("mobile") != -1) {
                 $scope.usermobile = qstring[i].split('=')[1];
            }
             else if (qstring[i].indexOf("bookdat") != -1) {
                 $scope.bookdate1 = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("available") != -1) {
                 $scope.available = qstring[i].split('=')[1];
            }
             else if (qstring[i].indexOf("booked") != -1) {
                 $scope.booked = qstring[i].split('=')[1];
            }
             else if (qstring[i].indexOf("service_id") != -1) {
                 $scope.serviceid = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("booking_id") != -1) {
                 $scope.booking_id = qstring[i].split('=')[1];
            }
             else if (qstring[i].indexOf("source") != -1) {
                 $scope.source = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("inventory_type") != -1) {
                 $scope.inventory_type = qstring[i].split('=')[1];
            }
        }

        

        var weekDay = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday","Saturday"];
        var datesplit = $scope.selDate.split("-");
        var tempdate = datesplit[1] - 1 + "-" + datesplit[0] + "-" + datesplit[2];
        var date = new Date(tempdate);
        $scope.dayShow = weekDay[date.getDay()];
        $scope.dateShow = montharray[datesplit[1] - 1] + " " + datesplit[0] + ", "  + datesplit[2]; 
        $scope.bookDate = datesplit[2].toString() + "-" +datesplit[1] + "-" + datesplit[0] + " 00:00:00";
        var newDate = new Date();
        var curdate = newDate.getDate();
        var curmonth = newDate.getMonth() + 1;
        var curyear = newDate.getFullYear();

        $scope.currentDate = curyear + "-" + curmonth + "-" + curdate + " 00:00:00";
    }

   $scope.clear = function()
   {
    $window.location.href = "index.html";
   }

   $scope.goBack = function()
    {
        var data = btoa("date=" + $scope.selDate + "&service_id=" + $scope.serviceid + "&package_id=" + $scope.packageId + "&provider_id=" + "11" + "&slot=" + $scope.selSlot + "&bookdat=" +  $scope.bookdate1 + "&available=" + $scope.available + "&booked=" + $scope.booked + "&inventory_type=" + $scope.inventory_type );
         $window.location.href = "listing.html?" + data;
    }
    $scope.submit = function()
    {
        var flag = 0;

        if($scope.username == undefined || $scope.username == "")
        {
            flag = 1;
            $scope.nameerror = "redbdr";
        }
        else{
            $scope.nameerror = "";
        }
        if($scope.usermobile == undefined || $scope.usermobile == "")
        {
            flag = 1;
             $scope.mobileerror = "redbdr";
        }
        else{
            $scope.mobileerror = "";
        }

        if(flag ==0 && $scope.booking_id == undefined)
        {
             $scope.Submittxt = "Submitting";
             $scope.disbtn = true;
            var reqdata = "payment_transaction_id=Null&player_id=Null" + "&name=" + $scope.username + "&mobile=" + $scope.usermobile
        + "&package_id=" + $scope.packageId + "&book_date=" + $scope.bookDate + "&cost_shown=Null&cost_paid=0&payment_status=1&transaction_date=" + $scope.currentDate + "&commission=0&cashback_applied=0&convenience_fees=0&discount=0&wallet_applied=0&source=SAAS&slot_names=" + $scope.selSlot;
         var request = $http({
            method: "POST",
            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'},
            dataType: "json",
            url: "http://ec2-34-193-7-167.compute-1.amazonaws.com/booking/new",
            data: reqdata
        });
          request.then(function (result) {
            if(result.data.success == 1)
            {
                $scope.showform = true;
                $scope.bookID = result.data.booking_id;
                $scope.Submittxt = "Submit";
                $scope.disbtn = false;
            }
        })
        }
        else if(flag ==0 && $scope.booking_id != undefined)
        {
             $scope.Submittxt = "Submitting";
             $scope.disbtn = true;
            var reqdata = "booking_id=" + $scope.booking_id +  "&name=" + $scope.username + "&mobile=" + $scope.usermobile
        +  "&book_date=" + $scope.bookDate + "&transaction_date=" + $scope.currentDate +  "&source=" + $scope.source +  "&slot_names=" + $scope.selSlot;
         var request = $http({
            method: "POST",
            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'},
            dataType: "json",
            url: "http://ec2-34-193-7-167.compute-1.amazonaws.com/edit/booking",
            data: reqdata
        });
          request.then(function (result) {
            if(result.data.success == 1)
            {
                $scope.showform = true;
                $scope.bookID = result.data.booking_id;
                $scope.Submittxt = "Submit";
                $scope.disbtn = false;
            }
        })
        }
        
    }
 }]);


app.directive('onlyLettersInput', onlyLettersInput);

function onlyLettersInput() {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                var transformedInput = text.replace(/[^a-zA-Z\s]/g, '');
                //console.log(transformedInput)
                if (transformedInput !== text) {
                    ngModelCtrl.$setViewValue(transformedInput);
                    ngModelCtrl.$render();
                }
                return transformedInput;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
};


app.directive('numbersOnly', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            function fromUser(text) {
                if (text) {
                     text = text.toString();
                    var transformedInput = text.replace(/[^0-9]/g, '');

                    if (transformedInput !== text) {
                        ngModelCtrl.$setViewValue(transformedInput);
                        ngModelCtrl.$render();
                    }
                    return transformedInput;
                }
                return undefined;
            }
            ngModelCtrl.$parsers.push(fromUser);
        }
    };
});