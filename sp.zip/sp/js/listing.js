
var app = angular.module( 'App', [] );


app.controller('Sportido', ["$scope", "$window", "$location", "$http",
 function ($scope, $window, $location,$http) {
 
    $scope.msg = "Hi";

    // var ctrl = this;
    
   


    $scope.init = function()
    {
        $scope.msgdata1 = "Exact";
        
        var url = $location.absUrl();
        url = url.split("#")[0];
        var data = atob(url.split("?")[1]);
        console.log(data);
        var qstring = data.split("&");
        for(var i=0;i<qstring.length;i++)
        {
            if (qstring[i].indexOf("date") != -1) {
                 $scope.selDate = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("provider_id") != -1) {
                 $scope.providerId = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("package_id") != -1) {
                 $scope.packageId = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("slot") != -1) {
                 $scope.selSlot = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("bookdat") != -1) {
                 $scope.bookdate = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("available") != -1) {
                 $scope.available = qstring[i].split('=')[1];
            }
             else if (qstring[i].indexOf("booked") != -1) {
                 $scope.booked = qstring[i].split('=')[1];
            }
             else if (qstring[i].indexOf("service_id") != -1) {
                 $scope.serviceid = qstring[i].split('=')[1];
            }
            else if (qstring[i].indexOf("inventory_type") != -1) {
                 $scope.inventory_type = qstring[i].split('=')[1];
            }
        }
        
        if($scope.booked >0)
        {
            apicall();
        }
        else{
            $scope.msgdata = [];
             availableSlots(0);
        }
        
    }

    function apicall()
    {
        var reqdata = "date_on=" + $scope.selDate + "&package_id=" + $scope.packageId + "&slot_name=" + $scope.selSlot;
         var request = $http({
            method: "POST",
            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=utf-8'},
            dataType: "json",
            url: "http://ec2-34-193-7-167.compute-1.amazonaws.com/saas/slots/landing",
            data: reqdata
        });
          request.then(function (result) {
            $scope.msgdata = [];
            if(result.data != undefined)
            {

                for(var i=0;i<result.data.data.length;i++)
                {
                    $scope.msgdata.push({court: $scope.inventory_type + " " + (i+1), booking_id: result.data.data[i].booking_id, name:result.data.data[i].player_name, booking: result.data.data[i].source, mobile:result.data.data[i].mobile, isBooked:1});
                }
                availableSlots(result.data.data.length);
                   }
            
        })
    }

    function availableSlots(len)
    {
        for(var i=0;i<$scope.available;i++)
            {
                $scope.msgdata.push({court:$scope.inventory_type + " " + (len + i+1), name:"", booking: "", mobile:"", isBooked:0})
            }
    }

    $scope.goBack = function()
    {
       var data = btoa("serviceid=" + $scope.serviceid + "&providerid="  +  $scope.providerId + "&inventory_type=" + $scope.inventory_type);
         $window.location.href = "home.html?" + data;
    }

    $scope.formFn = function(data)
    {

        var data = btoa("date=" + $scope.selDate  + "&service_id=" + $scope.serviceid  + "&package_id=" + $scope.packageId + "&provider_id=" + $scope.providerId +  "&slot=" + $scope.selSlot + "&court=" + data.court + "&name=" + data.name + "&mobile=" + data.mobile + "&bookdat=" + $scope.bookdate + "&available=" + $scope.available + "&booked=" + $scope.booked + "&booking_id=" + data.booking_id + "&source=" + data.booking + "&inventory_type=" + $scope.inventory_type );
        $window.location.href = "details.html?" + data;
    }

    

 }]);


